import pygame

pygame.init()

#still object constants
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 350
GROUND_HEIGHT = 14

MINE_WIDTH = 58
MINE_HEIGHT = 37
MINE1_POS = 40
MINE2_POS = SCREEN_WIDTH - 40

BARRACKS_WIDTH = 62
BARRACKS_HEIGHT = 50
BARRACKS1_POS = 106
BARRACKS2_POS = SCREEN_WIDTH - 106
BARRACKS_POS = (BARRACKS1_POS,BARRACKS2_POS)


TOWER_WIDTH = 50
TOWER_HEIGHT = 160
TOWER1_POS = 180
TOWER2_POS = SCREEN_WIDTH - 180
TOWER_POS = (TOWER1_POS,TOWER2_POS)

WALL_WIDTH = 62
WALL_HEIGHT = 80
WALL1_POS = 180
WALL2_POS = SCREEN_WIDTH -  180
WALL_POS= (WALL1_POS,WALL2_POS)


#worker class
WORKER_COST = 5
WORKER_TRAIN = 100
WORKER_PROD = 3
WORKER_SPEED = 1
WORKER_REPAIR = 3

#swordsman class
SWORD_COST = 5
SWORD_TRAIN = 200
SWORD_SPEED = 1
SWORD_RANGE = 20
SWORD_HIT = 2
SWORD_REST = 1
SWORD_HEALTH = 15

#archer class
ARCHER_COST = 40
ARCHER_TRAIN = 200
ARCHER_SPEED = 1
ARCHER_RANGE = 100
ARCHER_HIT = 10
ARCHER_REST = 1.5
ARCHER_HEALTH = 35

#arrow class
ARROW_SPEED = 2.5

#wall class
WALL_HEALTH = 100
WALL_HEALTH1 = 100
WALL_HEALTH2 = 100

#tower class
TOWER_RANGE = 220
TOWER_HIT = 6
TOWER_REST = 2

COIN_START = 10
COIN_START1 = 10
COIN_START2 = 10
MAX_COIN = 100

#create game window
screen = pygame.display.set_mode(( SCREEN_WIDTH, SCREEN_HEIGHT ))
pygame.display.set_caption("Castle's War")
#background
bg_image = pygame.image.load('img/Background/sky1.png').convert_alpha()
scaled_bg = pygame.transform.scale(bg_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
ground_image =pygame.image.load('img/Background/ground.jpg').convert_alpha()
scaled_ground= pygame.transform.scale(ground_image, (SCREEN_WIDTH, GROUND_HEIGHT))
#mine
MINE1_SURF = pygame.Surface((MINE_WIDTH, MINE_HEIGHT))
mine1_image = pygame.image.load ('img/buildings/Mine1.png').convert_alpha()
scaled_mine1= pygame.transform.scale(mine1_image, (MINE_WIDTH, MINE_HEIGHT))
MINE1_RECT = MINE1_SURF.get_rect( midbottom = (MINE1_POS, SCREEN_HEIGHT - GROUND_HEIGHT) )
#barracks
BARRACKS1_SURF = pygame.Surface((BARRACKS_WIDTH, BARRACKS_HEIGHT))
barracks1_image = pygame.image.load ('img/buildings/Barracks1.png').convert_alpha()
scaled_barracks1= pygame.transform.scale(barracks1_image, (BARRACKS_WIDTH, BARRACKS_HEIGHT))
BARRACKS1_RECT = BARRACKS1_SURF.get_rect( midbottom = (BARRACKS1_POS, SCREEN_HEIGHT - GROUND_HEIGHT) )
#tower
TOWER1_SURF = pygame.Surface((TOWER_WIDTH, TOWER_HEIGHT))
tower1_image = pygame.image.load ('img/buildings/Tower1.png').convert_alpha()
scaled_tower1= pygame.transform.scale(tower1_image, (TOWER_WIDTH, TOWER_HEIGHT))
TOWER1_RECT = TOWER1_SURF.get_rect( midbottom = (TOWER1_POS, SCREEN_HEIGHT - GROUND_HEIGHT) )
#wall
WALL1_SURF = pygame.Surface((WALL_WIDTH, WALL_HEIGHT))
wall1_image = pygame.image.load ('img/buildings/Wall1.png').convert_alpha()
scaled_wall1= pygame.transform.scale(wall1_image, (WALL_WIDTH, WALL_HEIGHT))
WALL1_RECT = WALL1_SURF.get_rect( midbottom = (WALL1_POS, SCREEN_HEIGHT - GROUND_HEIGHT) )
#player2
MINE2_SURF = pygame.Surface((MINE_WIDTH, MINE_HEIGHT))
mine2_image = pygame.image.load ('img/Buildings/Mine2.png').convert_alpha()
scaled_mine2= pygame.transform.scale(mine2_image, (MINE_WIDTH, MINE_HEIGHT))
MINE2_RECT = MINE2_SURF.get_rect( midbottom = (MINE2_POS, SCREEN_HEIGHT - GROUND_HEIGHT) )
#barracks
BARRACKS2_SURF = pygame.Surface((BARRACKS_WIDTH, BARRACKS_HEIGHT))
barracks2_image = pygame.image.load ('img/Buildings/Barracks2.png').convert_alpha()
scaled_barracks2 = pygame.transform.scale(barracks2_image, (BARRACKS_WIDTH, BARRACKS_HEIGHT))
scaled_barracks2_flipped = pygame.transform.flip(scaled_barracks2, True, False)
BARRACKS2_RECT = BARRACKS2_SURF.get_rect( midbottom = (BARRACKS2_POS, SCREEN_HEIGHT - GROUND_HEIGHT))
#tower
TOWER2_SURF = pygame.Surface((TOWER_WIDTH, TOWER_HEIGHT))
tower2_image = pygame.image.load ('img/Buildings/Tower2.png').convert_alpha()
scaled_tower2= pygame.transform.scale(tower2_image, (TOWER_WIDTH, TOWER_HEIGHT))
TOWER2_RECT = TOWER2_SURF.get_rect( midbottom = (TOWER2_POS, SCREEN_HEIGHT - GROUND_HEIGHT) )
#wall
WALL2_SURF = pygame.Surface((WALL_WIDTH, WALL_HEIGHT))
wall2_image = pygame.image.load ('img/buildings/Wall2.png').convert_alpha()
scaled_wall2= pygame.transform.scale(wall2_image, (WALL_WIDTH, WALL_HEIGHT))
WALL2_RECT = WALL2_SURF.get_rect( midbottom = (WALL2_POS, SCREEN_HEIGHT - GROUND_HEIGHT) )

wall_rect = (WALL1_RECT,WALL2_RECT)

#little image of sprites to keep count of troups
worker_image1 = pygame.image.load('img/sprites/player1/worker/dig1/dig-3.png').convert_alpha()
scaled_worker_image1 = pygame.transform.scale(worker_image1, (15, 15))
worker_image1_rect = scaled_worker_image1.get_rect(midbottom = (30,105))

worker_image2 = pygame.image.load('img/sprites/player2/worker/dig2/dig-1.png').convert_alpha()
scaled_worker_image2 = pygame.transform.scale(worker_image2, (15, 15))
worker_image2_rect = scaled_worker_image2.get_rect(midbottom = (SCREEN_WIDTH - 110,105))

sword_image1 = pygame.image.load('img/sprites/player1/sword/attack1/attack-3.png').convert_alpha()
scaled_sword_image1 = pygame.transform.scale(sword_image1, (15, 15))
sword_image1_rect = scaled_sword_image1.get_rect(midbottom = (30,125))

sword_image2 = pygame.image.load('img/sprites/player2/sword/attack2/attack-3.png').convert_alpha()
scaled_sword_image2 = pygame.transform.scale(sword_image2, (15, 15))
sword_image2_rect = scaled_sword_image2.get_rect(midbottom = (SCREEN_WIDTH - 110,125))

archer_image1 = pygame.image.load('img/sprites/player1/archer/attack1/shoot-0.png').convert_alpha()
scaled_archer_image1 = pygame.transform.scale(archer_image1, (15, 15))
archer_image1_rect = scaled_archer_image1.get_rect(midbottom = (30,145))

archer_image2 = pygame.image.load('img/sprites/player2/archer/attack2/shoot-0.png').convert_alpha()
scaled_archer_image2 = pygame.transform.scale(archer_image2, (15, 15))
archer_image2_rect = scaled_archer_image2.get_rect(midbottom = (SCREEN_WIDTH - 110,145))