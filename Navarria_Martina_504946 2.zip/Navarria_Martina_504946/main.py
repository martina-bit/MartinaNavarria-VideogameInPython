import sys
from Player import *
from Constants import *
import os
import pickle

# Constants
FPS = 60
clock = pygame.time.Clock()

class Game:
    def __init__(self):
        pygame.init()
        self.clock = pygame.time.Clock()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.player1 = Player(1)
        self.player2 = Player(2)
        self.player1.opponent = self.player2
        self.player2.opponent = self.player1
        self.ui1 = UI(screen, player_number= 1)
        self.ui2 = UI(screen, player_number= 2)
        self.player1_coins = Coins(player_number=1)
        self.player2_coins = Coins(player_number=2)
        self.all_coins = pygame.sprite.Group()
        self.all_coins.add(self.player1_coins, self.player2_coins)
        self.is_frozen = False
        self.game_over = False

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN: #unleash troups
                if event.key == pygame.K_q:
                    if self.player1.coin_start >= WORKER_COST:
                        self.player1.coin_start -= WORKER_COST
                        self.player1.create_worker()
                if event.key == pygame.K_p:
                    if self.player2.coin_start >= WORKER_COST:
                        self.player2.coin_start -= WORKER_COST
                        self.player2.create_worker()
                if event.key == pygame.K_w:
                    if self.player1.coin_start >= SWORD_COST:
                        self.player1.coin_start -= SWORD_COST
                        self.player1.create_sword()
                if event.key == pygame.K_o:
                    if self.player2.coin_start >= SWORD_COST:
                        self.player2.coin_start -= SWORD_COST
                        self.player2.create_sword()
                if event.key == pygame.K_e and len(self.player1.archer_list) <= 0: #indicate there can only exist one archer at a time for each player
                    if self.player1.coin_start >= ARCHER_COST:
                        self.player1.coin_start -= ARCHER_COST
                        self.player1.create_archer()
                if event.key == pygame.K_i and len(self.player2.archer_list) <= 0:
                    if self.player2.coin_start >= ARCHER_COST:
                        self.player2.coin_start -= ARCHER_COST
                        self.player2.create_archer()
                if event.key == pygame.K_SPACE and self.game_over == False:
                    self.freeze_game()


    def get_game_state_data(self):
        game_state_data = {'player1_data': self.player1.get_state_data(), 'player2_data': self.player2.get_state_data(), }
        return game_state_data

    def update(self):
        self.player1.update()
        self.player2.update()
        if self.player1.wall_health <= 0 or self.player2.wall_health <= 0:
            self.is_over()
        elif self.player1.coin_start <= 0 and len(self.player1.worker_list) == 0:
            self.is_over()
        elif self.player2.coin_start <= 0 and len(self.player2.worker_list) == 0:
            self.is_over()

    def run(self):
        while True:
            self.handle_events()
            self.update()
            self.change_state()
            self.clock.tick(FPS)

    def save_game_state(self, player1_data, player2_data):
        saved_data = {
            'player1_data': player1_data,
            'player2_data': player2_data
        }
        with open('game_state_data.pickle', 'wb') as file:
            pickle.dump(saved_data, file)

    # Function to load the game state data from a file
    def load_saved_data(self):
        try:
            with open('game_state_data.pickle', 'rb') as file:
                saved_data = pickle.load(file)
                return saved_data
        except FileNotFoundError:
            return None

    def show_intro_screen(self):
        screen.blit(scaled_bg, (0, 0))
        intro_font = pygame.font.Font('scribish.ttf', 36)
        intro_text = intro_font.render("Press any key to start a new game", True, (255, 255, 255))
        self.screen.blit(intro_text, (SCREEN_WIDTH // 2 - intro_text.get_width() // 2, SCREEN_HEIGHT // 2 - 50))

        # Check if any saved game file exists
        if os.path.isfile("saved_game_data.pickle"):
            load_text = intro_font.render("Press L to load a saved game", True, (255, 255, 255))
            delete_load_text = intro_font.render("Press X to delete a saved game and start a new one", True, (255, 255, 255))
            self.screen.blit(load_text, (SCREEN_WIDTH // 2 - load_text.get_width() // 2, SCREEN_HEIGHT // 2))
            self.screen.blit(delete_load_text, (SCREEN_WIDTH // 2 - delete_load_text.get_width() // 2, SCREEN_HEIGHT // 1 - 90))

        pygame.display.flip()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_l:
                        saved_data = load_game_data("saved_game_data.pickle")
                        if saved_data: # Load the saved data
                            self.player1.load_state(saved_data['player1_data'])
                            self.player2.load_state(saved_data['player2_data'])
                            self.is_frozen = False
                            self.game_over = False
                        self.run()
                    if event.key == pygame.K_x:
                        try:
                            os.remove("saved_game_data.pickle")
                            print(f"the game was successfully deleted")
                        except FileNotFoundError:
                            print(f"File not found.")
                        except Exception as e:
                            print(f"An error occurred : {e}")
                        return
                    else:# Start a new game here by resetting your game state
                        self.player1.reset()
                        self.player2.reset()
                        self.run()

    def change_state(self):
        global game_over_text
        if self.is_frozen: # If the game is frozen, make the screen slightly opaque
            overlay_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay_surface.set_alpha(1)  # Set the transparency (0 to 255, 0 is fully transparent)
            overlay_surface.fill((50, 50, 50))  # overlay
            self.screen.blit(overlay_surface, (0, 0))
            # Show the options to save or restart the game
            intro_font = pygame.font.Font('scribish.ttf', 36)
            pause_text = intro_font.render("- PAUSE -", True, (255, 255, 255))
            save_text = intro_font.render("Press 'S' to save the game", True, (255, 255, 255))
            restart_text = intro_font.render("Press 'R' to restart the game", True, (255, 255, 255))
            go_back_text = intro_font.render("Press the space bar to resume", True, (255, 255, 255))
            self.screen.blit(save_text, (SCREEN_WIDTH // 2 - save_text.get_width() // 2, SCREEN_HEIGHT // 2 - 50))
            self.screen.blit(restart_text, (SCREEN_WIDTH // 2 - restart_text.get_width() // 2, SCREEN_HEIGHT // 2))
            self.screen.blit(pause_text, (SCREEN_WIDTH // 2 - pause_text.get_width() // 2, SCREEN_HEIGHT // 2 - 100))
            self.screen.blit(go_back_text, (SCREEN_WIDTH // 2 - go_back_text.get_width() // 2, SCREEN_HEIGHT// 1 - 90))

        elif self.game_over:
            overlay_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay_surface.set_alpha(1)
            overlay_surface.fill((50, 50, 50))
            screen.blit(overlay_surface, (0, 0))
            game_over_font = pygame.font.Font('scribish.ttf', 36)
            if self.player1.wall_health <= 0 :
                game_over_text = game_over_font.render('Player 2 has won!', True, (0,0,255))
            elif self.player2.wall_health <= 0 :
                game_over_text = game_over_font.render('Player 1 has won!', True, (255,0,0))
            elif self.player1.coin_start <= 0 and len(self.player1.worker_list) == 0:
                game_over_text = game_over_font.render('Player 2 has won!', True, (0, 0, 255))
            elif self.player2.coin_start <= 0 and len(self.player2.worker_list) == 0:
                game_over_text = game_over_font.render('Player 1 has won!', True, (0, 0, 255))
            restart_text = game_over_font.render("Press 'N' to start a new game", True, (255, 255, 255))
            screen.blit(game_over_text, (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, SCREEN_HEIGHT // 2 - 50))
            self.screen.blit(restart_text, (SCREEN_WIDTH // 2 - restart_text.get_width() // 2, SCREEN_HEIGHT // 2))

        else: #drawing logic for the game state
            self.is_frozen = False # If the game is not frozen or over, draw the normal game state
            self.game_over = False
            screen.blit(scaled_bg, (0, 0))
            screen.blit(scaled_ground, (0, 336))
            screen.blit(scaled_mine1, MINE1_RECT)
            screen.blit(scaled_barracks1, BARRACKS1_RECT)
            screen.blit(scaled_tower1, TOWER1_RECT)
            screen.blit(scaled_wall1, WALL1_RECT)
            screen.blit(scaled_mine2, MINE2_RECT)
            screen.blit(scaled_barracks2_flipped, BARRACKS2_RECT)
            screen.blit(scaled_tower2, TOWER2_RECT)
            screen.blit(scaled_wall2, WALL2_RECT)
            screen.blit(scaled_worker_image1, worker_image1_rect)
            screen.blit(scaled_worker_image2, worker_image2_rect)
            screen.blit(scaled_sword_image1, sword_image1_rect)
            screen.blit(scaled_sword_image2, sword_image2_rect)
            screen.blit(scaled_archer_image1, archer_image1_rect)
            screen.blit(scaled_archer_image2, archer_image2_rect)
            self.player1.worker_list.draw(self.screen)
            self.player1.sword_list.draw(self.screen)
            self.player1.archer_list.draw(self.screen)
            self.player2.worker_list.draw(self.screen)
            self.player2.sword_list.draw(self.screen)
            self.player2.archer_list.draw(self.screen)
            self.player1.arrow_list.draw(self.screen)
            self.player2.arrow_list.draw(self.screen)
            self.ui1.show_health(self.player1.wall_health)
            self.ui2.show_health(self.player2.wall_health)
            self.ui1.show_coins(self.player1.coin_start)
            self.ui2.show_coins(self.player2.coin_start)
            self.ui1.show_sprite_n(len(self.player1.worker_list), (50, 100))
            self.ui2.show_sprite_n(len(self.player2.worker_list), (SCREEN_WIDTH - 90, 100))
            self.ui1.show_sprite_n(len(self.player1.sword_list), (50, 120))
            self.ui2.show_sprite_n(len(self.player2.sword_list), (SCREEN_WIDTH - 90, 120))
            self.ui1.show_sprite_n(len(self.player1.archer_list), (50, 140))
            self.ui2.show_sprite_n(len(self.player2.archer_list), (SCREEN_WIDTH - 90, 140))
            self.all_coins.draw(self.screen)
            self.all_coins.update()

        pygame.display.flip()

    def freeze_game(self):
        self.is_frozen = True
        while self.is_frozen:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:# Check for key presses while the game is frozen
                    if event.key == pygame.K_s:
                        # Save the game data when 'S' is pressed
                        game_state_data = self.get_game_state_data()
                        save_game_data(game_state_data, "saved_game_data.pickle")
                        self.show_intro_screen()

                    elif event.key == pygame.K_r:
                        self.player1.reset()
                        self.player2.reset()
                        self.is_frozen = False

                    elif event.key == pygame.K_SPACE: # Unfreeze the game if space key is pressed
                        self.is_frozen = False
            self.change_state()  # Redraw the game state with the frozen overlay

    def is_over(self):
        self.game_over = True
        while self.game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_n:
                        self.player1.reset()
                        self.player2.reset()
                        self.game_over = False

            self.change_state()

if __name__ == '__main__':
    game = Game()
    game.show_intro_screen()
    game.run()