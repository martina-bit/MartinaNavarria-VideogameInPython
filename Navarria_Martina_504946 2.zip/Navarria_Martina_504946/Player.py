import pygame

from Constants import *
from os import walk
import pickle


def import_folder(path): #path to create movement with the sprites
    sprite_list = []
    for _, __, img_files in walk(path):
        for image in img_files:
            if not image.startswith('.'):
                full_path = f'{path}/{image}'
                image_sprite = pygame.image.load(full_path).convert_alpha()
                sprite_list.append(image_sprite)

    return sprite_list

def save_game_data(data, filename):
    with open(filename, 'wb') as f:
        pickle.dump(data, f)

def load_game_data(filename):
    try:
        with open(filename, 'rb') as f:
            return pickle.load(f)
    except FileNotFoundError:
        return None

class Player:
    def __init__(self, number):
        self.number = number
        self.barracks_pos = 106 if number == 1 else SCREEN_WIDTH - 106
        self.wall_rect = WALL1_RECT if number == 1 else WALL2_RECT
        self.mine_rect = MINE1_RECT if number == 1 else MINE2_RECT
        self.wall_health = WALL_HEALTH
        self.coin_start = COIN_START
        self.move_forward_key = pygame.K_s if number == 1 else pygame.K_l
        self.move_backward_key = pygame.K_a if number == 1 else pygame.K_k
        self.attack_sword_key = pygame.K_d if number == 1 else pygame.K_j
        self.attack_archer_key = pygame.K_f if number == 1 else pygame.K_h
        self.dispatch_all_key = pygame.K_z if number == 1 else pygame.K_m
        self.worker_list = pygame.sprite.Group()
        self.sword_list = pygame.sprite.Group()
        self.archer_list =pygame.sprite.Group()
        self.arrow_list = pygame.sprite.Group()

    def get_state_data(self):
        # Return a dictionary containing all the relevant player data
        player_data = {
            'number': self.number,
            'barracks_pos': self.barracks_pos,
            'wall_health': self.wall_health,
            'coin_start': self.coin_start,
            'worker_list': self.get_unit_list_data(self.worker_list),
            'sword_list': self.get_unit_list_data(self.sword_list),
            'archer_list': self.get_unit_list_data(self.archer_list),
            'arrow_list': self.get_unit_list_data(self.arrow_list),
        }
        return player_data

    def load_state(self, state_data):
        self.barracks_pos = state_data['barracks_pos']
        self.wall_health = state_data['wall_health']
        self.coin_start = state_data['coin_start']

        # Load worker list data
        self.worker_list.empty()
        for unit_data in state_data['worker_list']:
            worker = Worker(self)
            worker.health = unit_data['health']
            worker.rect.x = unit_data['position']
            self.worker_list.add(worker)

        # Load sword list data
        self.sword_list.empty()
        for unit_data in state_data['sword_list']:
            sword = Sword(self)
            sword.health = unit_data['health']
            sword.rect.x = unit_data['position']
            self.sword_list.add(sword)

        # Load archer list data
        self.archer_list.empty()
        for unit_data in state_data['archer_list']:
            archer = Archer(self)
            archer.health = unit_data['health']
            archer.rect.x = unit_data['position']
            self.archer_list.add(archer)

    def get_unit_list_data(self, unit_list):
        # Return a list of dictionaries, each containing the state data for a unit in the given unit_list
        unit_list_data = []
        for unit in unit_list:
            unit_data = {
                'health': unit.health,
                'position': unit.rect.x,
            }
            unit_list_data.append(unit_data)
        return unit_list_data

    def reset(self): # Reset all player-related attributes here
        self.worker_list.empty()
        self.sword_list.empty()
        self.archer_list.empty()
        self.arrow_list.empty()
        self.wall_health = WALL_HEALTH
        self.coin_start = COIN_START

    def update(self):
        self.worker_list.update()
        self.sword_list.update()
        self.archer_list.update()
        self.arrow_list.update()

    def create_worker(self):
        worker = Worker(self)
        self.worker_list.add(worker)

    def create_sword(self):
        sword = Sword(self)
        self.sword_list.add(sword)

    def create_archer(self):
        archer = Archer(self)
        self.archer_list.add(archer)

class Unit(pygame.sprite.Sprite):
    def __init__(self, player):
        super().__init__()
        self.player = player
        self.frame_index = 0
        self.animation_speed = 0.20
        self.dx = 0
        self.status = f'ready{self.player.number}'
        self.mortostramorto = False

    def import_assets(self, path):
        self.animations = {f'attack{self.player.number}': [], f'fallen{self.player.number}': [], f'runback{self.player.number}': [], f'ready{self.player.number}': [], f'run{self.player.number}': [], f'dig{self.player.number}': [], f'repair{self.player.number}':[]}
        for animation in self.animations.keys():
            full_path = path + animation
            self.animations[animation] = import_folder(full_path)

    def animate(self):
        animation = self.animations[self.status]
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0
        self.image = animation[int(self.frame_index)]

    def death(self):
        if self.health <= 0 and self.status != f'fallen{self.player.number}':
            self.status = f'fallen{self.player.number}'
            if self.status == f'fallen{self.player.number}':
                self.dx = 0  # Stop movement
                self.frame_index = 0
                self.mortostramorto = True

        if self.mortostramorto == True :
            if self.frame_index >= len(self.animations[self.status]) - 1:
                self.kill() # Remove the sprite from the game

class Worker(Unit):
    def __init__(self, player):
        super().__init__(player)
        self.import_worker_assets()
        self.image = self.animations[f'ready{self.player.number}'][self.frame_index]
        self.rect = self.image.get_rect(midbottom=(self.player.barracks_pos, SCREEN_HEIGHT - GROUND_HEIGHT))
        self.traintime = 0
        self.speed = WORKER_SPEED
        self.health= 100
        self.move_forward_key = False
        self.move_backward_key = False

    def import_worker_assets(self):
        worker_path = f'img/sprites/player{self.player.number}/worker/'
        self.import_assets(worker_path)

    def get_input(self):
        self.traintime += 1
        keys = pygame.key.get_pressed()

        if keys[self.player.move_forward_key] and not self.move_backward_key:
            self.move_forward_key = True

        elif keys[self.player.move_backward_key] and not self.move_forward_key:
            self.move_backward_key = True

        if self.traintime >= WORKER_TRAIN:
            if self.move_forward_key and not (self.status == f'repair{self.player.number}' or self.status == f'runback{self.player.number}' or self.status == f'dig{self.player.number}'):
                self.dx = self.speed
                self.status = f'run{self.player.number}'
                self.traintime = 0
            elif self.move_backward_key and not (self.status == f'dig{self.player.number}' or self.status == f'run{self.player.number}' or self.status == f'repair{self.player.number}'):
                self.dx = -self.speed
                self.status = f'runback{self.player.number}'
                self.traintime = 0

        self.rect.x += self.dx

    def collision(self):
        if self.rect.colliderect(self.player.wall_rect):
            if self.player.wall_health <= WALL_HEALTH:
                self.status = f'repair{self.player.number}'
                self.dx = 0
                if self.frame_index == 0:
                    self.player.wall_health += WORKER_REPAIR
                    if self.player.wall_health >= WALL_HEALTH:
                        self.kill()
                        self.player.wall_health = 100
            elif self.player.wall_health >= WALL_HEALTH:
                self.kill()
        if self.rect.colliderect(self.player.mine_rect):
            if self.player.coin_start <= MAX_COIN:
                self.status = f'dig{self.player.number}'
                self.dx = 0
                if self.frame_index == 0:
                    self.player.coin_start += WORKER_PROD
                    if self.player.coin_start >= MAX_COIN:
                        self.kill()
                        self.player.coin_start = 100
            elif self.player.coin_start >= MAX_COIN:
                self.kill()

    def update(self):
        self.import_worker_assets()
        self.collision()
        self.get_input()
        self.animate()

class Sword (Unit):
    def __init__(self, player):
        super().__init__(player)
        self.import_sword_assets()
        self.image = self.animations[f'ready{self.player.number}'][self.frame_index]
        self.rect = self.image.get_rect(midbottom=(self.player.barracks_pos, SCREEN_HEIGHT - GROUND_HEIGHT))
        self.speed = SWORD_SPEED
        self.health = SWORD_HEALTH
        self.traintime = 0
        self.attack_sword_key = False

    def import_sword_assets(self):
        sword_path = f'img/sprites/player{self.player.number}/sword/'
        self.import_assets(sword_path)

    def get_input(self):
        self.traintime += 1
        keys = pygame.key.get_pressed()

        if keys[self.player.attack_sword_key]:
            self.attack_sword_key = True
        if self.traintime >= SWORD_TRAIN:
            if self.attack_sword_key and not (self.status == f'attack{self.player.number}' or self.status == f'fallen{self.player.number}'):
                self.dx = self.speed if self.player.number == 1 else -self.speed
                self.status = f'run{self.player.number}'
                self.traintime = 0
        self.rect.x += self.dx

    def attack_units(self, enemy_player):
        if pygame.sprite.spritecollideany(self, enemy_player.sword_list):
            self.dx = 0
            if self.health > 0:
                self.status = f'attack{self.player.number}'

            for enemy in enemy_player.sword_list:
                if enemy.status == f'attack{enemy.player.number}':
                    if enemy.frame_index == 0:
                        self.health -= SWORD_HIT

            else:
                return self.death()

        elif pygame.sprite.spritecollideany(self, enemy_player.archer_list):
            self.dx = 0
            if self.health > 0:
                self.status = f'attack{self.player.number}'

            for enemy in enemy_player.archer_list:
                if self.status == f'attack{self.player.number}' :
                    if self.frame_index == 0:
                        enemy.health -= SWORD_HIT
            else:
                return self.death()

        elif self.rect.colliderect(self.player.opponent.wall_rect):
            self.dx = 0
            if self.health >= 0:
                self.status = f'attack{self.player.number}'
                if self.frame_index == 0:
                    self.player.opponent.wall_health -= SWORD_HIT

            else:
                return self.death()

        elif not (self.status == f'ready{self.player.number}' or self.status == f'fallen{self.player.number}'):
            self.status = f'run{self.player.number}'
            self.dx = self.speed if self.player.number == 1 else -self.speed


    def update(self ):
        self.import_sword_assets()
        self.get_input()
        self.attack_units(self.player.opponent)
        self.animate()

class Archer(Unit):
    def __init__(self, player):
        super().__init__(player)
        self.import_archer_assets()
        self.image = self.animations[f'ready{self.player.number}'][self.frame_index]
        self.rect = self.image.get_rect(midbottom=(self.player.barracks_pos, SCREEN_HEIGHT - GROUND_HEIGHT))
        self.speed = ARCHER_SPEED
        self.health = ARCHER_HEALTH
        self.traintime = 0
        self.attack_archer_key = False

    def import_archer_assets(self):
        archer_path = f'img/sprites/player{self.player.number}/archer/'
        self.import_assets(archer_path)

    def get_input(self):
        self.traintime += 1
        keys = pygame.key.get_pressed()

        if keys[self.player.attack_archer_key]:
            self.attack_archer_key = True

        if self.traintime >= ARCHER_TRAIN:
            if self.attack_archer_key and not (self.status == f'attack{self.player.number}' or self.status == f'fallen{self.player.number}'):
                self.dx = self.speed if self.player.number == 1 else -self.speed
                self.status = f'run{self.player.number}'
        self.rect.x += self.dx

    def fight(self, enemy_player):
        if self.health <= 0:
            return self.death()

        self.shooting_range = pygame.Rect(self.rect.centerx - 30 if self.player.number == 1 else self.rect.centerx + 30 , self.rect.y,
                                          (ARCHER_RANGE if self.player.number == 1 else - ARCHER_RANGE),
                                          self.rect.height)


        temp = self.rect
        self.rect = self.shooting_range
        if  pygame.sprite.spritecollideany(self, enemy_player.sword_list):
            self.status = f'attack{self.player.number}'
            self.dx = 0
            self.animation_speed = 0.05
            if self.frame_index == 0:
                self.shoot()
        elif  pygame.sprite.spritecollideany(self, enemy_player.archer_list):
            self.shooting = True
            self.status = f'attack{self.player.number}'
            self.dx = 0
            self.animation_speed = 0.05
            if self.frame_index == 0:
                self.shoot()

        elif self.shooting_range.colliderect(enemy_player.wall_rect):
            self.status = f'attack{self.player.number}'
            self.dx = 0
            self.animation_speed = 0.05
            if self.frame_index == 0:
                self.shoot()

        elif not (self.status == f'ready{self.player.number}' or self.status == f'fallen{self.player.number}'):
            self.status = f'run{self.player.number}'
            self.dx = self.speed if self.player.number == 1 else -self.speed

        self.rect = temp

    def shoot(self):
        arrow_x = self.rect.centerx
        arrow_y = self.rect.centery
        arrow = Arrow(arrow_x, arrow_y, self.player.number, self.player.opponent)
        self.player.arrow_list.add(arrow)

    def update(self):
        self.import_archer_assets()
        self.fight(self.player.opponent)
        self.get_input()
        self.animate()


class Arrow(pygame.sprite.Sprite):
    def __init__(self, x, y, player_number, enemy):
        super().__init__()
        self.player_number = player_number
        self.image = pygame.image.load(f'img/sprites/player{self.player_number}/archer/arrows/arrowoz{self.player_number}/arrowhor-0.png').convert_alpha()
        self.rect = self.image.get_rect(center=(x, y))
        self.dx = (ARROW_SPEED if player_number == 1 else -ARROW_SPEED)
        self.has_hit = False
        self.opponent = enemy

    def impact(self, enemy):
        if not self.has_hit:
            if pygame.sprite.spritecollideany(self, enemy.sword_list):
                self.has_hit = True
                self.kill()
            if pygame.sprite.spritecollideany(self, enemy.archer_list):
                self.has_hit = True
                self.kill()
            if self.rect.colliderect(enemy.wall_rect):
                self.has_hit = True
                self.kill()

    def collide(self):
        if self.rect.colliderect(self.opponent.wall_rect):
            self.opponent.wall_health -= ARCHER_HIT
        sprite = pygame.sprite.spritecollide(self, self.opponent.sword_list, False)
        if sprite:
            sprite[0].health -= ARCHER_HIT
            self.kill()
        sprite = pygame.sprite.spritecollide(self, self.opponent.archer_list, False)
        if sprite:
            sprite[0].health -= ARCHER_HIT
            self.kill()

    def update(self):
        if self.player_number == 1:
            self.rect.x += ARROW_SPEED
        elif self.player_number == 2:
            self.rect.x -= ARROW_SPEED
        self.collide()
        self.impact(self.opponent)

class Coins(pygame.sprite.Sprite): #moving animation for resources icon
    def __init__(self, player_number):
        super().__init__()
        self.import_coin_assets()
        self.frame_index = 0
        self.animation_speed = 0.20
        self.image = self.animations['coins'][self.frame_index]

        # Determine the position based on the player number
        if player_number == 1:
            self.rect = self.image.get_rect(midbottom=(30, 70))
        elif player_number == 2:
            self.rect = self.image.get_rect(midbottom=(SCREEN_WIDTH - 40, 70))

        self.dx = 0
        self.status = 'coins'

    def import_coin_assets(self):
        coin_path = 'img/sprites/'
        self.animations = {'coins': []}
        for animation in self.animations.keys():
            full_path = coin_path + animation
            self.animations[animation] = import_folder(full_path)

    def animate(self):
        animation = self.animations[self.status]
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0
        self.image = animation[int(self.frame_index)]

    def update(self):
        self.animate()

class UI():
    def __init__(self, surface, player_number):
        self.display_surface = surface
        self.bar_max_width = 200
        self.bar_height = 10
        self.player_number = player_number

    def show_health(self, amount): #wall health bar
        if self.player_number == 1:
            health_bar_topleft = (20, 30)
            current_health_ratio = amount / WALL_HEALTH
            current_bar_width = self.bar_max_width * current_health_ratio
            health_bar_rect = pygame.Rect(health_bar_topleft, (current_bar_width, self.bar_height))
            pygame.draw.rect(self.display_surface, ( '#FFFF00' if amount < 40 else '#dc4949'), health_bar_rect) #alert the player when the wall health gets low
        elif self.player_number == 2:
            health_bar_topright = (SCREEN_WIDTH - 20, 30)
            current_health_ratio = amount / WALL_HEALTH
            current_bar_width = self.bar_max_width * current_health_ratio
            health_bar_rect = pygame.Rect(health_bar_topright, (current_bar_width, self.bar_height))
            health_bar_rect.left, health_bar_rect.right = health_bar_rect.right, health_bar_rect.left
            pygame.draw.rect(self.display_surface, ('#FFFF00' if amount < 40 else '#dc4949'), health_bar_rect)

    def show_coins(self, amount): #resources amount
        self.font = pygame.font.Font('scribish.ttf', 20)
        if self.player_number == 1:
            coin_surf = self.font.render(str(amount), False, ((0, 0, 0) if amount < ARCHER_COST else (0,238,0))) #indicate when player has enough resources to unleash the Archer
            coin_rect = coin_surf.get_rect(midleft=(50, 60))
            self.display_surface.blit(coin_surf, coin_rect)
        elif self.player_number == 2:
            coin_surf = self.font.render(str(amount), False, ((0, 0, 0) if amount < ARCHER_COST else (0,238,0)))
            coin_rect = coin_surf.get_rect(midright=(SCREEN_WIDTH - 90, 60))
            self.display_surface.blit(coin_surf, coin_rect)

    def show_sprite_n(self, amount, position): #sprite count
        self.font = pygame.font.Font('scribish.ttf', 10)
        sprite_surf = self.font.render(str(amount), False, (0, 0, 0))
        sprite_rect = sprite_surf.get_rect(midleft=position)
        self.display_surface.blit(sprite_surf, sprite_rect)

